FanWoolf

Summary -
A demo game developed by Alvin H. Revilas (Programmer) and Courtney Tucker (Artist)

Install -
After unzipping the compressed folder, run the "setup.exe" file.  All support files should be in the same directory as "setup.exe".

Details -
Created with C# using the XNA games library.  Was a Senior project for the Visual and Game Programming degree, obtained from the Art Institute of San Diego California.  

This implementation was exported as a Windows compatible application that can use the X Box controller.  

The game's theme, including the background song, was inspired by the 1980's TV show "Airwolf".

Game Controls -
	Keyboard -
		Movement:  Arrow Keys
		Fire:  Spacebar
		Start / Pause / Resume game:  "P" key
		View game credits:  "C" key
		Quit game:  "Esc" key

	XBox Controller -
		Movement:  Left Thumbstick
		Fire:  Right Trigger (can hold for automatic fire)
		Start / Pause / Resume game:  "Start" button
		View game credits:  "X" button
		Quit game:  "Back" button

Contacting Information -
	Alvin:  alvinrevilas@yahoo.com
	Courtney:  court.m.tucker@gmail.com